    ----------------------------------------------------------

    bbIconBox is a plugin for Blackbox for Windows.

    Copyright 2004-2009 grischka
    http://bb4win.sourceforge.net/bblean


    bbIconBox is free software, released under the GNU General
    Public License (GPL version 2). For details see:

        http://www.fsf.org/licenses/gpl.html


    THIS PROGRAM IS DISTRIBUTED IN THE HOPE THAT IT
    WILL BE USEFUL, BUT WITHOUT ANY WARRANTY; WITHOUT
    EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR
    FITNESS FOR A PARTICULAR PURPOSE.

    ----------------------------------------------------------

    bbIconBox displays icons in a box for either
      - the contents of a folder
      - the currently running tasks
      - or the systemtray


    Mouse Clicks:
    -------------

    Common:
      Ctrl-Right:           Configuration Menu

    Folder
      Left:                 Activate
      Right:                ContextMenu
      Drop on Icon:         Drop File to Application
      Drop on empty space:  Copy/Move File to Folder

    Tasks:
      Left:                 Activate Task
      Right:                Minimize
      Shift-Right:          Close Task

      Mid/DoubleLeft:       Move to next Workspace
      with shift:           Move to previous Workspace
      Shift-Left:           Zoom into Current Workspace

    Tray:
      Mouse clicks are passed to the program.



    ----------------------------------------------------------
    History:

    [20-May-2009] v 1.17
    - update version for release with bbLean 1.17

    [03-Mai-2005] v 0.2
    - fixed tooltip buffer overflow with long (128+) applications-titles.

    [05-Apr-2005] v 0.1
    - initial release
