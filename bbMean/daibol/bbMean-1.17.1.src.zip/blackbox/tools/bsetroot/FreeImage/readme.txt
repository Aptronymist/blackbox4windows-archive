In order to compile bsetroot, you can also use alternatively

    FreeImage - http://freeimage.sourceforge.net/

Version used: 3.7.0
