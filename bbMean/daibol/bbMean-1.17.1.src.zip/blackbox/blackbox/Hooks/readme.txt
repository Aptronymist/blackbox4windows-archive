
    -----------------------------------------------------------------

    deskhook and trayhook are free software, released under the
    GNU General Public License (GPL version 2):

            http://www.fsf.org/licenses/gpl.html

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for details.

    
    deskhook.dll:
    -------------
    Needed by blackbox.exe when this option is enabled in extensions.rc:

        blackbox.options.desktopHook: true

    deskhook.dll must be in the blackbox directory.


    trayhook.dll:
    -------------
    When blackbox runs under explorer this slightly improves the tracking
    of system tray items. Used automatically when present in the blackbox
    directory, no other settings required.

    -----------------------------------------------------------------

